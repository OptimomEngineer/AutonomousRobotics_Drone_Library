# pocketsphinx
Files for library
